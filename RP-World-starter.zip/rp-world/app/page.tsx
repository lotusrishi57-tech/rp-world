import Link from "next/link";

const demoCharacters = [
  { name: "Keerthana", role: "Warm-hearted neighbor", emoji: "🌸", color: "from-pink-500/30" },
  { name: "Ananya", role: "Cheerful little girl", emoji: "🧸", color: "from-violet-500/30" },
  { name: "Vikram", role: "Loyal best friend", emoji: "🕶️", color: "from-blue-500/30" },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,#27213d_0,#09090b_45%)]">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
        <div className="text-2xl font-black tracking-tight">RP <span className="text-violet-400">World</span></div>
        <Link href="/create" className="rounded-xl bg-violet-500 px-4 py-2 font-semibold hover:bg-violet-400">+ Create Character</Link>
      </nav>

      <section className="mx-auto max-w-6xl px-5 pb-14 pt-12">
        <div className="max-w-3xl">
          <div className="mb-4 inline-flex rounded-full border border-violet-400/20 bg-violet-400/10 px-3 py-1 text-sm text-violet-300">
            ✨ Custom AI roleplay
          </div>
          <h1 className="text-5xl font-black leading-tight sm:text-7xl">
            Your characters.<br />
            <span className="text-violet-400">Your world.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-zinc-400">
            Create original characters, build immersive stories, and continue your roleplays with persistent chat history.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/create" className="rounded-2xl bg-violet-500 px-6 py-3 font-bold hover:bg-violet-400">Create your first character</Link>
            <Link href="/chat" className="rounded-2xl border border-zinc-700 px-6 py-3 font-bold hover:bg-zinc-900">Open demo chat</Link>
          </div>
        </div>

        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {demoCharacters.map(c => (
            <Link key={c.name} href="/chat" className={`rounded-3xl border border-zinc-800 bg-gradient-to-br ${c.color} to-zinc-950 p-6 transition hover:-translate-y-1 hover:border-violet-500/40`}>
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-zinc-900 text-3xl">{c.emoji}</div>
              <h2 className="mt-5 text-xl font-bold">{c.name}</h2>
              <p className="mt-1 text-zinc-400">{c.role}</p>
              <div className="mt-6 text-sm font-semibold text-violet-300">Start roleplay →</div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
