 "use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Message = { role: "user" | "assistant"; content: string };

function renderMessage(text: string) {
  const parts = text.split(/(\*[^*]+\*)/g);
  return parts.map((p, i) => p.startsWith("*") && p.endsWith("*")
    ? <em key={i}>{p.slice(1, -1)}</em>
    : <span key={i}>{p}</span>);
}

export default function Chat() {
  const [character, setCharacter] = useState<any>(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("rp-world-character");
    if (saved) setCharacter(JSON.parse(saved));
    const history = localStorage.getItem("rp-world-messages");
    if (history) setMessages(JSON.parse(history));
  }, []);

  useEffect(() => {
    localStorage.setItem("rp-world-messages", JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    if (character && messages.length === 0 && character.first) {
      setMessages([{ role: "assistant", content: character.first }]);
    }
  }, [character]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ character, messages: next })
      });
      if (!res.ok || !res.body) throw new Error("Chat request failed");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let answer = "";
      setMessages([...next, { role: "assistant", content: "" }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        answer += decoder.decode(value, { stream: true });
        setMessages([...next, { role: "assistant", content: answer }]);
      }
    } catch {
      setMessages([...next, { role: "assistant", content: "*pauses for a moment* I couldn't connect to the roleplay server. Add your AI API key to continue." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex h-screen flex-col bg-[#09090b]">
      <header className="flex items-center gap-3 border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <Link href="/" className="mr-2 text-zinc-400">←</Link>
        <div className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-full bg-violet-500/20">
          {character?.avatar ? <img src={character.avatar} alt="" className="h-full w-full object-cover" /> : "🌸"}
        </div>
        <div>
          <div className="font-bold">{character?.name || "Keerthana"}</div>
          <div className="text-xs text-green-400">● Roleplay active</div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="mx-auto flex max-w-3xl flex-col gap-3">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-3 leading-7 ${
                m.role === "user" ? "rounded-br-md bg-violet-500 text-white" : "rounded-bl-md bg-zinc-900 text-zinc-200"
              }`}>
                {renderMessage(m.content)}
              </div>
            </div>
          ))}
          {loading && <div className="text-sm text-zinc-500">typing…</div>}
        </div>
      </div>

      <div className="border-t border-zinc-800 bg-zinc-950 p-3">
        <form onSubmit={e => { e.preventDefault(); send(); }} className="mx-auto flex max-w-3xl gap-2">
          <input value={input} onChange={e => setInput(e.target.value)}
            placeholder="Type your message..." className="min-w-0 flex-1 rounded-2xl border border-zinc-800 bg-zinc-900 px-4 py-3 outline-none focus:border-violet-500" />
          <button disabled={loading} className="rounded-2xl bg-violet-500 px-5 font-bold disabled:opacity-50">➤</button>
        </form>
      </div>
    </main>
  );
}
